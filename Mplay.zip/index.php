<?php 

?>
<!DOCTYPE html>
<html>
<head>
        <!-- ads -->
        <meta name="site-verification" content="f0cd7cbd27361fda488be6fdd2956e51"/>
<script type="text/javascript" src="https://cdn.diclotrans.com/sdk/v1/24496/50cbce40fa75672bf13593ebeb6fdce962f73990/lib.js"></script>

	<title>MPlayer</title>
	<meta name="robots" content="noindex">
	<link id=favicon rel="shortcut icon" type=image/x-icon href=favicon.ico><link rel=preconnect href=https://delivrjs.github.io>
	<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	<script type="text/javascript" src="https://ssl.p.jwpcdn.com/player/v/8.23.1/jwplayer.js"></script>
	<script type="text/javascript">jwplayer.key="XSuP4qMl+9tK17QNb+4+th2Pm9AWgMO/cYH8CI0HGGr7bdjo";</script>
	<style type="text/css" media="screen">html,body{padding:0;margin:0;height:100%}#cf-player{width:100%!important;height:100%!important;overflow:hidden;background-color:#000}</style>
</head>
<body>

<?php 
error_reporting(0);

$data = (isset($_GET['data'])) ? $_GET['data'] : '';

if ($data != '') {
	
	include_once 'config.php';

	$data = json_decode(decode($data));

	$link = (isset($data->link)) ? $data->link : '';

	$sub = (isset($data->sub)) ? $data->sub : '';

	$poster = (isset($data->poster)) ? $data->poster : '';

	$tracks = '';
	
	foreach ($sub as $key => $value) {
		$tracks .= '{ 
						file: "'.$value.'", 
						label: "'.$key.'",
						kind: "captions"
					   },';
	}

	include_once 'curl.php';

	$curl = new cURL();

	$sources = '[{"label":"HD","type":"video\/mp4","file":"'.$link.'"}]';

	$result = '<div id="cf-player"></div>';

	$data = 'var player = jwplayer("cf-player");
				player.setup({
					sources: '.$sources.',
					advertising: {
                    client: "vast",
                skiptext: "Skip Ad",
                skipmessage: "Skip Ad in  XX",
                admessage: "Skip ad in XX .",
                    schedule: {
                        adbreak1: {                       
                            offset: "pre",
                            tag: "",
                            skipoffset: 5,
                        },
                        adbreak2: {
                            offset: "100%",
                            tag: "",
                            skipoffset: 3,
                        },
                        adbreak3: {
                            offset: "100%",
                            tag: "",
                            skipoffset: 3,
                        }
                    }},
                    sharing: "false",
                    playbackRateControls: "true",
					aspectratio: "16:9",
					startparam: "start",
					primary: "html5",
					autostart: false,
					preload: "auto",
					aboutlink: "https://moviekh.net",
					abouttext: "MPlayer",
					image: "https://moviekh.net/wp-content/uploads/2023/12/moviekh.gif",
					imageX: "'.$poster.'",
					logo: {
						file: "https://moviekh.net/wp-content/uploads/2023/12/Moviekh-net.png",
						link: "",
                        hide: "false",
						position: "top-right"
					},
                    			skin: {
                    				url: "https://res.cloudinary.com/do1zdkwaj/raw/upload/v1704087632/SUB/neflex_uoodhg.css",
		    				name: "Netplex"
		    			},
                    			autoPause: {
    						viewability: "true",
    						pauseAds: "true"
					},
					captions: {
						color: "white",
						fontSize: 16,
						backgroundOpacity: 0,
						fontfamily: "Helvetica",
						edgeStyle: "raised"
					},
					tracks: ['.$tracks.']
				});
				player.on("setupError", function() {
				  swal("Server Error!", "Please PM Me to fix it. Thank you!", "error");
				});
				player.on("error" , function(){
					swal("Reload Browser!", "Your Internet Connection Problems, choose a different server", "error");
				});';
	
	$packer = new Packer($data, 'Normal', true, false, true);

	$packed = $packer->pack();

	$result .= '<script type="text/javascript">' . $packed . ' player.on("ready",function(){let e=player.getContainer(),r=e.querySelector(".jw-button-container");r.querySelector(".jw-spacer");let o=e.querySelector(".jw-display-icon-rewind"),n=o.cloneNode(!0),t=n.querySelector(".jw-icon-rewind");t.style.transform="scaleX(-1)",t.ariaLabel="Forward 10 Seconds";let l=e.querySelector(".jw-display-icon-next");l.parentNode.insertBefore(n,l),e.querySelector(".jw-display-icon-next").style.display="none";let c=r.querySelector(".jw-icon-rewind"),i=c.cloneNode(!0);i.style.transform="scaleX(-1)",i.ariaLabel="Forward 10 Seconds",c.parentNode.insertBefore(i,c.nextElementSibling),[t,i].forEach(e=>{e.onclick=()=>{player.seek(player.getPosition()+10)}})});</script>';

	echo $result;

} else echo 'Empty link!';

$script .= "(function(){'use strict';const devtools={isOpen:false,orientation:undefined};const threshold=160;const emitEvent=(isOpen,orientation)=>{window.dispatchEvent(new CustomEvent('devtoolschange',{detail:{isOpen,orientation}}));};const main=({emitEvents=true}={})=>{const widthThreshold=window.outerWidth-window.innerWidth>threshold;const heightThreshold=window.outerHeight-window.innerHeight>threshold;const orientation=widthThreshold?'vertical':'horizontal';if(!(heightThreshold&&widthThreshold)&&((window.Firebug&&window.Firebug.chrome&&window.Firebug.chrome.isInitialized)||widthThreshold||heightThreshold)){if((!devtools.isOpen||devtools.orientation!==orientation)&&emitEvents){emitEvent(true,orientation);}
devtools.isOpen=true;devtools.orientation=orientation;}else{if(devtools.isOpen&&emitEvents){emitEvent(false,undefined);}
devtools.isOpen=false;devtools.orientation=undefined;}};main({emitEvents:false});setInterval(main,500);if(typeof module!=='undefined'&&module.exports){module.exports=devtools;}else{window.devtools=devtools;}})();
";
	
$script .= "const redirect = 'https://cdn.jsdelivr.net/gh/kiprox/cf-gdplay@master/assets/img/93656b62-2a01-4649-b2f3-84e9d0dde40a.jpg';if(window.devtools.isOpen){
  window.location.href  = redirect;}window.addEventListener('devtoolschange', event => {if(event.detail.isOpen){window.location.href  = redirect;}});";

?>

</body>
</html>
